# Ordering from JLCPCB (fab + assembly)

## Files
- `openmanet_power_adapter_gerbers.zip` - Gerbers + PTH/NPTH drill, upload as-is
- `BOM.csv` - bill of materials
- `CPL.csv` - placement file (all parts on **Top**)

## 1. PCB
- Layers **4**, 1.6mm, default stackup is fine (the design assumes F.Cu-to-In1 is the thin prepreg).
- Outer copper 1oz (default) is fine.
- **Inner copper: pick 1oz if offered** (JLC's 4-layer default is 0.5oz). The 5V/GND
  distribution to the headers now runs on In1/In2, and 1oz halves its voltage drop
  (~0.07V instead of ~0.13V at 3A). 0.5oz still works.
- Via covering: tented (default). No via-in-pad is used, so no epoxy fill is needed.

## 2. Assembly (PCBA), top side
Upload `BOM.csv` + `CPL.csv`. Parts with an LCSC number are pinned to the part the
footprint was taken from:

| Ref | Part | LCSC |
|---|---|---|
| U1 | TPS552892RYQR buck-boost | C19272254 |
| U2, U3 | LM74700QDBVRQ1 ideal-diode controller | C2941042 |
| Q1, Q2 | DMT6007LFGQ-7 60V N-FET | C5624212 |
| L1 | Eaton HCM0703-4R7-R, 4.7uH / 10A sat | C427309 |
| D1 | SMBJ28A TVS | C178227 |
| J3 | XT30PW-M (THT, right angle) | C431092 |

**L1 stock was low (about 50 pcs) when I checked.** Any shielded 4.7uH molded inductor
with a 7.1x6.6mm footprint, Isat >= 9A and DCR <= 40mR is a drop-in replacement.

Passives have a blank LCSC column. Let JLC's matcher pick by the Comment text (value,
voltage, dielectric, package are all in it). Keep the voltage ratings: 50V for C10/C11/C8/C15,
25V for the rest.

**Check the rotation preview** in JLC's placement viewer before paying, especially U1, U2/U3,
Q1/Q2 and D1/D2 polarity. The LCSC-library parts should line up as-is; KiCad-library
passives occasionally need a 180-degree correction, which only matters for D2 (LED) and C1
(electrolytic). Pad 1 of D2 = cathode and pad 1 of C1 = `+`.

## THT parts
J1, J2 (2x20 headers) and J3 (XT30) are through-hole. Either add JLC's THT assembly or
hand-solder them. J3 is 2 pins + 2 pegs, and its front overhangs the left board edge by
0.55mm on purpose.

## Before submitting
- Open the board in KiCad and eyeball the Pi/expansion orientation as before.
- Confirm XT30 polarity against your harness (see README).
