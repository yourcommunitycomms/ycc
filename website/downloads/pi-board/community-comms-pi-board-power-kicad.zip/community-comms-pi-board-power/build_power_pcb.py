"""openmanet GPIO relocator + on-board 5-24V -> 5.2V buck-boost supply.

Base (holes, J1/J2, inner-layer GPIO bus) is identical to
openmanet_gpio_adapter/build_pcb5.py. New: a 22mm power strip added on the LEFT
edge (x = -4.5 .. 17.5), outside the expansion board's footprint, carrying:

  J3 XT30 in -> Q1/U2 ideal-diode reverse-polarity protection -> TVS + bulk
  -> U1 TPS552892 4-switch buck-boost (5.19V, 5A output current limit)
  -> Q2/U3 ideal-diode OR-ing -> "5V" rail

F.Cu/B.Cu stay bare outside the strip (as on the original). The 5V rail reaches both
headers' 5V pins through wide In2 bands, and GND returns on In1 directly underneath,
using the corridors above/below the GPIO lane band. So the Pi no longer depends on
the 0.25mm lanes for its supply current.
"""
import math
import os
import pcbnew

MM = pcbnew.FromMM
PROJ = os.path.dirname(os.path.abspath(__file__))
OUT = PROJ + r"\openmanet_power_adapter.kicad_pcb"
FP_BASE = r"C:\Program Files\KiCad\10.0\share\kicad\footprints"
LOCAL_LIB = PROJ + r"\openmanet_power.pretty"

PINMAP = {
    1: "3V3", 2: "5V", 3: "GPIO02_SDA1", 4: "5V", 5: "GPIO03_SCL1",
    6: "GND", 7: "GPIO04_GPCLK0", 8: "GPIO14_TXD", 9: "GND", 10: "GPIO15_RXD",
    11: "GPIO17", 12: "GPIO18_PCM_CLK_PWM0", 13: "GPIO27", 14: "GND", 15: "GPIO22",
    16: "GPIO23", 17: "3V3", 18: "GPIO24", 19: "GPIO10_MOSI0", 20: "GND",
    21: "GPIO09_MISO0", 22: "GPIO25", 23: "GPIO11_SCLK0", 24: "GPIO08_CE0", 25: "GND",
    26: "GPIO07_CE1", 27: "ID_SD", 28: "ID_SC", 29: "GPIO05", 30: "GND",
    31: "GPIO06", 32: "GPIO12_PWM0", 33: "GPIO13_PWM1", 34: "GND", 35: "GPIO19_MISO1",
    36: "GPIO16", 37: "GPIO26", 38: "GPIO20_MOSI1", 39: "GND", 40: "GPIO21_SCLK1",
}
POWER_NETS = {"3V3", "5V", "GND"}
PSU_NETS = ["VIN_RAW", "VIN_P", "SW1", "SW2", "BOOT1", "BOOT2", "VCC", "EN", "FSW",
            "FB", "COMP", "COMP_RC", "VOUT_REG", "VOUT_S", "GATE1", "VCAP1",
            "GATE2", "VCAP2", "LED_A"]

HAT_H1 = (20.0, 20.0)
PI_H1 = (100.0, 20.0)
HOLE_DX, HOLE_DY = 58.0, 49.0
HDR_OFFSET = (4.88, 1.28)

board = pcbnew.BOARD()
board.SetCopperLayerCount(4)

nets = {}
for name in sorted(set(PINMAP.values())) + PSU_NETS:
    n = pcbnew.NETINFO_ITEM(board, name)
    board.Add(n)
    nets[name] = n

bom = []  # (ref, value, footprint, lcsc)


def add_footprint(lib, name, pos_mm, rot_deg):
    fp = pcbnew.FootprintLoad(FP_BASE + "\\" + lib, name)
    fp.SetPosition(pcbnew.VECTOR2I(MM(pos_mm[0]), MM(pos_mm[1])))
    fp.SetOrientationDegrees(rot_deg)
    board.Add(fp)
    return fp

# =====================================================================================
# BASE BOARD - unchanged from openmanet_gpio_adapter/build_pcb5.py
# =====================================================================================


def add_holes(lib_name, origin, offsets, ref_prefix, text_size_mm=1.0):
    for i, (dx, dy) in enumerate(offsets):
        hx, hy = origin[0] + dx, origin[1] + dy
        fp = add_footprint("MountingHole.pretty", lib_name, (hx, hy), 0)
        fp.SetReference(f"{ref_prefix}{i+1}")
        ref = fp.Reference()
        ref.SetVisible(True)
        ref.SetTextSize(pcbnew.VECTOR2I(MM(text_size_mm), MM(text_size_mm)))
        ref.SetTextThickness(MM(text_size_mm * 0.15))
        ref.SetPosition(pcbnew.VECTOR2I(MM(hx + 2.6), MM(hy)))


hole_offsets = [(0, 0), (HOLE_DX, 0), (0, HOLE_DY), (HOLE_DX, HOLE_DY)]
add_holes("MountingHole_2.7mm_M2.5", PI_H1, hole_offsets, "H_PI")
add_holes("MountingHole_2.7mm_M2.5", HAT_H1, hole_offsets, "H_EXP")

j2_pos = (HAT_H1[0] + HDR_OFFSET[0], HAT_H1[1] + HDR_OFFSET[1])
j2 = add_footprint("Connector_PinHeader_2.54mm.pretty", "PinHeader_2x20_P2.54mm_Vertical", j2_pos, 90)
j2.SetReference("J2")
j2.SetValue("EXPANSION_GPIO_MALE")

j1 = add_footprint("Connector_PinSocket_2.54mm.pretty", "PinSocket_2x20_P2.54mm_Vertical", (0, 0), 90)
j1.SetReference("J1")
j1.SetValue("PI4_GPIO_FEMALE_FLIPPED")
J1_ANCHOR_X = PI_H1[0] + HDR_OFFSET[0]
J1_ANCHOR_Y = PI_H1[1] + HOLE_DY - HDR_OFFSET[1]
j1.SetPosition(pcbnew.VECTOR2I(MM(J1_ANCHOR_X), MM(J1_ANCHOR_Y)))
for item in list(j1.GraphicalItems()):
    j1.Remove(item)

j1_odd_y = J1_ANCHOR_Y
j1_even_y = J1_ANCHOR_Y + 2.54
j1_x0 = J1_ANCHOR_X - 1.8
j1_x1 = J1_ANCHOR_X + 19 * 2.54 + 1.8
j1_y0 = min(j1_odd_y, j1_even_y) - 1.5
j1_y1 = max(j1_odd_y, j1_even_y) + 1.5


def add_fp_rect(fp, layer, x0, y0, x1, y1, width_mm=0.12):
    shape = pcbnew.PCB_SHAPE(fp)
    shape.SetShape(pcbnew.SHAPE_T_RECT)
    shape.SetStart(pcbnew.VECTOR2I(MM(x0), MM(y0)))
    shape.SetEnd(pcbnew.VECTOR2I(MM(x1), MM(y1)))
    shape.SetLayer(layer)
    shape.SetWidth(MM(width_mm))
    fp.Add(shape)


add_fp_rect(j1, pcbnew.F_SilkS, j1_x0, j1_y0, j1_x1, j1_y1)
j1.Reference().SetPosition(pcbnew.VECTOR2I(MM(J1_ANCHOR_X), MM(j1_y0 - 1.2)))
j1.Value().SetPosition(pcbnew.VECTOR2I(MM(J1_ANCHOR_X), MM(j1_y1 + 1.4)))

for pin, netname in PINMAP.items():
    j1.FindPadByNumber(str(pin)).SetNet(nets[netname])
    j2.FindPadByNumber(str(pin)).SetNet(nets[netname])

EDGE_MARGIN = 2.5
PANEL_X_LEFT = 21.0
PANEL_X_RIGHT = 157.0
MID_Y = (HAT_H1[1] + HAT_H1[1] + HOLE_DY) / 2
PANEL_SPACING = 17.5
panel_holes = {
    "H_PANEL1": (PANEL_X_LEFT, MID_Y - PANEL_SPACING),
    "H_PANEL3": (PANEL_X_LEFT, MID_Y),
    "H_PANEL5": (PANEL_X_LEFT, MID_Y + PANEL_SPACING),
    "H_PANEL2": (PANEL_X_RIGHT, MID_Y - PANEL_SPACING),
    "H_PANEL4": (PANEL_X_RIGHT, MID_Y),
    "H_PANEL6": (PANEL_X_RIGHT, MID_Y + PANEL_SPACING),
}
GAP_X = (HAT_H1[0] + HOLE_DX + PI_H1[0]) / 2
panel_holes["H_PANEL7"] = (GAP_X, HAT_H1[1])
panel_holes["H_PANEL8"] = (GAP_X, HAT_H1[1] + HOLE_DY)

J2_TOP_PIN_Y = j2_pos[1] - 2.54
by0 = min(HAT_H1[1], J2_TOP_PIN_Y) - EDGE_MARGIN
bx1 = PI_H1[0] + HOLE_DX + EDGE_MARGIN
by1 = max(HAT_H1[1] + HOLE_DY, J1_ANCHOR_Y + 2.54) + EDGE_MARGIN
# NEW: left edge moved out by 22mm to hold the power supply strip.
STRIP_W = 22.0
bx0 = HAT_H1[0] - EDGE_MARGIN - STRIP_W   # = -4.5

for ref_name, pos in panel_holes.items():
    fp = add_footprint("MountingHole.pretty", "MountingHole_3.2mm_M3", pos, 0)
    fp.SetReference(ref_name)
    ref = fp.Reference()
    ref.SetVisible(True)
    ref.SetTextSize(pcbnew.VECTOR2I(MM(1.0), MM(1.0)))
    ref.SetTextThickness(MM(0.15))

LANE_Y0 = 26.5
LANE_STEP = 0.93
STUB_LAYER = pcbnew.In1_Cu
BUS_LAYER = pcbnew.In2_Cu
SIG_W = MM(0.25)
VIA_DIA = MM(0.6)
VIA_DRILL = MM(0.3)
FAR_NUDGE = MM(1.27)


def make_track(start, end, layer, width, net):
    t = pcbnew.PCB_TRACK(board)
    t.SetStart(start)
    t.SetEnd(end)
    t.SetLayer(layer)
    t.SetWidth(width)
    t.SetNet(net)
    board.Add(t)


def make_via(pos, net):
    v = pcbnew.PCB_VIA(board)
    v.SetPosition(pos)
    v.SetWidth(VIA_DIA)
    v.SetDrill(VIA_DRILL)
    v.SetNet(net)
    board.Add(v)


FAR_PARITY = {"J1": 0, "J2": 0}
j1_bends, j2_bends = {}, {}
for pin in range(1, 41):
    net = nets[PINMAP[pin]]
    lane_y = MM(LANE_Y0 + (pin - 1) * LANE_STEP)
    for fp, bends, ref in ((j1, j1_bends, "J1"), (j2, j2_bends, "J2")):
        pad_pos = fp.FindPadByNumber(str(pin)).GetPosition()
        if (pin % 2) == FAR_PARITY[ref]:
            jog = pcbnew.VECTOR2I(pad_pos.x + FAR_NUDGE, pad_pos.y)
            bend = pcbnew.VECTOR2I(pad_pos.x + FAR_NUDGE, lane_y)
            make_track(pad_pos, jog, STUB_LAYER, SIG_W, net)
            make_track(jog, bend, STUB_LAYER, SIG_W, net)
        else:
            bend = pcbnew.VECTOR2I(pad_pos.x, lane_y)
            make_track(pad_pos, bend, STUB_LAYER, SIG_W, net)
        make_via(bend, net)
        bends[pin] = bend
    make_track(j2_bends[pin], j1_bends[pin], BUS_LAYER, SIG_W, net)

outline = pcbnew.PCB_SHAPE(board)
outline.SetShape(pcbnew.SHAPE_T_RECT)
outline.SetStart(pcbnew.VECTOR2I(MM(bx0), MM(by0)))
outline.SetEnd(pcbnew.VECTOR2I(MM(bx1), MM(by1)))
outline.SetLayer(pcbnew.Edge_Cuts)
outline.SetWidth(MM(0.1))
board.Add(outline)


def add_text(text, pos_mm, layer=pcbnew.F_SilkS, size_mm=1.4, rot_deg=0):
    t = pcbnew.PCB_TEXT(board)
    t.SetText(text)
    t.SetPosition(pcbnew.VECTOR2I(MM(pos_mm[0]), MM(pos_mm[1])))
    t.SetLayer(layer)
    t.SetTextSize(pcbnew.VECTOR2I(MM(size_mm), MM(size_mm)))
    t.SetTextThickness(MM(size_mm * 0.15))
    if rot_deg:
        t.SetTextAngleDegrees(rot_deg)
    board.Add(t)


add_text("EXPANSION SIDE (male)", (HAT_H1[0] + 6, HAT_H1[1] + 4.6), size_mm=0.9)
add_text("PI SIDE (female)", (PI_H1[0] + 6, PI_H1[1] + 4.6), size_mm=0.9)
for ref_name, pos in panel_holes.items():
    for fp in board.GetFootprints():
        if fp.GetReference() == ref_name:
            fp.Reference().SetPosition(pcbnew.VECTOR2I(MM(pos[0]), MM(pos[1] + 3.5)))

# =====================================================================================
# POWER SUPPLY STRIP (x = -4.5 .. 17.5)
# =====================================================================================

ROT = {"right": 0, "left": 180, "up": 90, "down": -90}


def style_ref(fp, size=0.6):
    r = fp.Reference()
    r.SetTextSize(pcbnew.VECTOR2I(MM(size), MM(size)))
    r.SetTextThickness(MM(size * 0.15))
    r.SetVisible(False)   # too dense for silkscreen refs; see ASSEMBLY/ BOM for locations


def replace_courtyard(fp, x0, y0, x1, y1):
    """EasyEDA courtyards are drawn smaller than the pads - redraw a proper one.
    Must be called while the footprint is still at origin / rotation 0."""
    for item in list(fp.GraphicalItems()):
        if item.GetLayer() == pcbnew.F_CrtYd:
            fp.Remove(item)
    add_fp_rect(fp, pcbnew.F_CrtYd, x0, y0, x1, y1, width_mm=0.05)


def place(ref, lib, name, pos, rot, value, pad_nets, lcsc="", local=False, crtyd=None):
    fp = pcbnew.FootprintLoad(LOCAL_LIB if local else FP_BASE + "\\" + lib, name)
    if local:
        fp.SetAttributes(pcbnew.FP_SMD if name.startswith(("PDFN", "VQFN", "SOT", "SMB", "IND"))
                         else pcbnew.FP_THROUGH_HOLE)
        fp.Models().clear()
    if crtyd:
        replace_courtyard(fp, *crtyd)
    fp.SetReference(ref)
    fp.SetValue(value)
    fp.SetPosition(pcbnew.VECTOR2I(MM(pos[0]), MM(pos[1])))
    fp.SetOrientationDegrees(rot)
    for padnum, netname in pad_nets.items():
        for pad in fp.Pads():
            if pad.GetNumber() == str(padnum):
                pad.SetNet(nets[netname])
    style_ref(fp)
    fp.Value().SetVisible(False)
    board.Add(fp)
    bom.append((ref, value, name, lcsc, fp))
    return fp


def place2(ref, lib, name, center, direction, net1, net2, value, lcsc=""):
    """2-pin part: pad 1 -> pad 2 points in `direction` (up/down/left/right)."""
    return place(ref, lib, name, center, ROT[direction], value, {1: net1, 2: net2}, lcsc)


def trk(pts, w, net, layer=pcbnew.F_Cu):
    for a, b in zip(pts, pts[1:]):
        make_track(pcbnew.VECTOR2I(MM(a[0]), MM(a[1])), pcbnew.VECTOR2I(MM(b[0]), MM(b[1])),
                   layer, MM(w), nets[net])


def via(x, y, net):
    make_via(pcbnew.VECTOR2I(MM(x), MM(y)), nets[net])


def zone(net, layer, pts, priority, clearance=0.25, full=True, min_w=0.2):
    z = pcbnew.ZONE(board)
    z.SetLayer(layer)
    z.SetNet(nets[net])
    ol = z.Outline()
    ol.NewOutline()
    for x, y in pts:
        ol.Append(MM(x), MM(y))
    z.SetAssignedPriority(priority)
    z.SetLocalClearance(MM(clearance))
    z.SetMinThickness(MM(min_w))
    z.SetPadConnection(pcbnew.ZONE_CONNECTION_FULL if full else pcbnew.ZONE_CONNECTION_THERMAL)
    z.SetThermalReliefGap(MM(0.3))
    z.SetThermalReliefSpokeWidth(MM(0.8))
    z.SetIslandRemovalMode(pcbnew.ISLAND_REMOVAL_MODE_ALWAYS)
    board.Add(z)
    return z


def rect(x0, y0, x1, y1):
    return [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]


R0402, C0402 = ("Resistor_SMD.pretty", "R_0402_1005Metric"), ("Capacitor_SMD.pretty", "C_0402_1005Metric")
R0603, C0603 = ("Resistor_SMD.pretty", "R_0603_1608Metric"), ("Capacitor_SMD.pretty", "C_0603_1608Metric")
C0805 = ("Capacitor_SMD.pretty", "C_0805_2012Metric")
C1210 = ("Capacitor_SMD.pretty", "C_1210_3225Metric")
R1206 = ("Resistor_SMD.pretty", "R_1206_3216Metric")
LED0603 = ("LED_SMD.pretty", "LED_0603_1608Metric")
CP63 = ("Capacitor_SMD.pretty", "CP_Elec_6.3x7.7")

# ---- U1: TPS552892 buck-boost, VQFN-HR-21 (pads 7-11 are the long VIN/SW1/PGND/SW2/VOUT strips) ----
U1X, U1Y = 6.0, 29.0
U1 = place("U1", None, "VQFN-21_L5.0-W3.0-P0.50-TL", (U1X, U1Y), 0, "TPS552892RYQR",
           {1: "EN", 2: "GND", 5: "GND", 6: "FSW", 7: "VIN_P", 8: "SW1", 9: "GND", 10: "SW2",
            11: "VOUT_REG", 12: "VOUT_REG", 13: "VOUT_S", 14: "FB", 15: "COMP", 17: "GND",
            18: "VCC", 19: "BOOT2", 20: "BOOT1"},
           lcsc="C19272254", local=True, crtyd=(-2.95, -1.95, 2.95, 1.95))
# pins 3 PG, 4 CC, 16 CDC, 21 EXTVCC intentionally unconnected (open-drain flags / no cable
# comp / EXTVCC floating = internal VCC LDO, per datasheet)

# ---- L1 4.7uH above U1, pad1 = SW1 (left), pad2 = SW2 (right) ----
place("L1", None, "IND-SMD_L7.1-W6.6", (6.0, 21.3), 0, "4.7uH 10A (Eaton HCM0703-4R7-R)",
      {1: "SW1", 2: "SW2"}, lcsc="C427309", local=True, crtyd=(-4.25, -3.55, 4.25, 3.55))

place2("C3", *C0402, (4.46, 25.9), "up", "BOOT1", "SW1", "100nF 25V X7R 0402")
place2("C4", *C0402, (7.54, 25.9), "up", "BOOT2", "SW2", "100nF 25V X7R 0402")
trk([(4.46, 27.3), (4.46, 26.38)], 0.25, "BOOT1")
trk([(7.54, 27.3), (7.54, 26.38)], 0.25, "BOOT2")
trk([(5.46, 27.3), (5.46, 25.42), (4.46, 25.42)], 0.25, "SW1")
trk([(6.54, 27.3), (6.54, 25.42), (7.54, 25.42)], 0.25, "SW2")
zone("SW1", pcbnew.F_Cu, rect(1.9, 19.4, 5.72, 25.75), 5)
zone("SW2", pcbnew.F_Cu, rect(6.28, 19.4, 10.1, 25.75), 5)

# ---- VCC (pin 18) ----
place2("C5", *C0805, (11.3, 25.9), "up", "VCC", "GND", "10uF 16V X5R 0805")
trk([(8.04, 27.62), (9.8, 27.62), (10.8, 27.0)], 0.25, "VCC")
via(11.3, 23.9, "GND"); via(12.7, 24.95, "GND")
trk([(11.3, 24.95), (11.3, 23.9)], 0.4, "GND"); trk([(11.3, 24.95), (12.7, 24.95)], 0.4, "GND")

# ---- AGND (pin 17) ----
trk([(8.7, 28.25), (9.7, 28.35)], 0.25, "GND")
via(9.7, 28.35, "GND")

# ---- COMP network (pin 15): Rc 4.99k + Cc 22nF to GND, Cp 100pF to GND ----
place2("R3", *R0402, (11.1, 28.2), "right", "COMP", "COMP_RC", "4.99k 1% 0402")
place2("C6", *C0402, (11.1, 29.25), "right", "COMP", "GND", "100pF 50V C0G 0402")
place2("C7", *C0402, (13.0, 28.2), "right", "COMP_RC", "GND", "22nF 50V X7R 0402")
trk([(8.7, 29.25), (10.62, 29.25), (10.62, 28.2)], 0.2, "COMP")
trk([(11.58, 28.2), (12.52, 28.2)], 0.2, "COMP_RC")
trk([(11.58, 29.25), (12.5, 29.35)], 0.25, "GND"); via(12.5, 29.35, "GND")
trk([(13.48, 28.2), (14.3, 28.2)], 0.25, "GND"); via(14.3, 28.2, "GND")

# ---- FB (pin 14): 100k top (from VOUT_REG) / 30.1k bottom -> VOUT = 1.2*(1+100/30.1) = 5.19V ----
place2("R4", *R0402, (11.1, 30.3), "right", "FB", "GND", "30.1k 1% 0402")
place2("R5", *R0402, (11.1, 31.35), "right", "FB", "VOUT_REG", "100k 1% 0402")
trk([(8.7, 29.75), (9.3, 29.75), (9.8, 30.25), (10.62, 30.3), (10.62, 31.35)], 0.2, "FB")
trk([(11.58, 30.3), (12.4, 30.45)], 0.25, "GND"); via(12.4, 30.45, "GND")
trk([(11.58, 31.35), (11.58, 32.5)], 0.25, "VOUT_REG")

# ---- EN/UVLO (pin 1): 100k / 43k from VIN_P -> on at 4.09V, off at ~3.6V ----
place2("R2", *R0402, (0.0, 27.6), "up", "EN", "GND", "43k 1% 0402")
place2("R1", *R0402, (0.0, 29.6), "down", "EN", "VIN_P", "100k 1% 0402")
trk([(3.3, 28.25), (0.0, 28.25)], 0.2, "EN")
trk([(0.0, 28.39), (0.0, 28.81)], 0.2, "EN")
trk([(0.0, 27.12), (0.0, 25.9)], 0.25, "GND"); via(0.0, 25.9, "GND")
trk([(0.0, 30.08), (0.0, 32.6)], 0.3, "VIN_P")

# ---- MODE (pin 2) -> GND = auto-PFM at light load (datasheet: must not float) ----
trk([(3.3, 28.75), (2.3, 28.95)], 0.2, "GND"); via(2.3, 28.95, "GND")
# ---- DITH/SYNC (pin 5) -> GND = no dithering ----
trk([(3.9, 30.45), (2.4, 30.45)], 0.2, "GND"); via(2.4, 30.45, "GND")
# ---- FSW (pin 6): 49.9k -> 400kHz ----
place2("R6", *R0402, (2.72, 31.6), "left", "FSW", "GND", "49.9k 1% 0402")
trk([(4.46, 30.6), (4.46, 31.6), (3.23, 31.6)], 0.2, "FSW")
trk([(2.21, 31.6), (1.2, 31.6)], 0.25, "GND"); via(1.2, 31.6, "GND")

# ---- HF decoupling right at the strip ends ----
place2("C8", *C0402, (5.6, 31.6), "right", "VIN_P", "GND", "100nF 50V X7R 0402")
place2("C9", *C0402, (6.52, 32.6), "right", "GND", "VOUT_REG", "100nF 25V X7R 0402")
trk([(4.96, 30.6), (4.96, 30.9)], 0.25, "VIN_P")
trk([(4.96, 30.9), (5.12, 31.6), (5.12, 32.6)], 0.4, "VIN_P")      # strip end -> C8 -> VIN_P zone
trk([(6.0, 30.6), (6.0, 31.2), (6.08, 31.6)], 0.25, "GND")
trk([(6.08, 31.6), (6.04, 32.6)], 0.25, "GND")
trk([(7.04, 30.6), (7.04, 31.0)], 0.25, "VOUT_REG")
trk([(7.04, 31.0), (7.0, 32.6)], 0.4, "VOUT_REG")
for y in (33.55, 34.55, 35.55, 36.55):
    via(6.05, y, "GND")
trk([(6.04, 32.6), (6.05, 36.55)], 0.4, "GND")

# ---- ISP (pin 12) joins VOUT_REG; ISN (pin 13) Kelvin-routed on In2 to R_SNS pad 2 ----
trk([(7.54, 30.6), (7.54, 32.5)], 0.2, "VOUT_REG")
trk([(8.04, 30.6), (8.04, 30.9), (8.35, 31.55)], 0.2, "VOUT_S")
via(8.35, 31.55, "VOUT_S")
trk([(8.35, 31.55), (15.5, 31.55), (15.5, 38.1)], 0.2, "VOUT_S", layer=pcbnew.In2_Cu)
via(15.5, 38.1, "VOUT_S")   # lands in the F.Cu VOUT_S zone right under R7 pad 2

# ---- Input caps (VIN_P side) ----
place2("C10", *C1210, (-2.3, 35.0), "down", "VIN_P", "GND", "10uF 50V X7R 1210")
place2("C11", *C1210, (2.1, 35.0), "down", "VIN_P", "GND", "10uF 50V X7R 1210")
for x in (-3.0, -1.6):
    via(x, 37.7, "GND")
for x in (1.4, 2.8):
    via(x, 37.7, "GND")
trk([(-2.3, 36.5), (-2.3, 37.7), (-3.0, 37.7)], 0.5, "GND"); trk([(-2.3, 37.7), (-1.6, 37.7)], 0.5, "GND")
trk([(2.1, 36.5), (2.1, 37.7), (1.4, 37.7)], 0.5, "GND"); trk([(2.1, 37.7), (2.8, 37.7)], 0.5, "GND")

# ---- Output caps (VOUT_REG side) + 10mR output-current sense (50mV/10mR = 5A limit) ----
place2("C12", *C1210, (9.1, 35.0), "down", "VOUT_REG", "GND", "22uF 25V X5R 1210")
place2("C13", *C1210, (12.3, 35.0), "down", "VOUT_REG", "GND", "22uF 25V X5R 1210")
place2("R7", *R1206, (15.1, 35.5), "down", "VOUT_REG", "VOUT_S", "10mR 1% 0.5W 1206")
for x in (8.25, 9.95, 11.45, 13.0):
    via(x, 37.8, "GND")
trk([(9.1, 36.5), (9.1, 37.8)], 0.5, "GND"); trk([(8.25, 37.8), (9.95, 37.8)], 0.5, "GND")
trk([(12.3, 36.5), (12.3, 37.8)], 0.5, "GND"); trk([(11.45, 37.8), (13.0, 37.8)], 0.5, "GND")

# ---- Bulk input cap + TVS (after the reverse-polarity FET, so a reversed input can't
#      forward-bias the TVS) ----
place2("C1", *CP63, (-1.1, 44.2), "down", "VIN_P", "GND", "47uF 50V aluminium 6.3x7.7")
place("D1", None, "SMB_L4.6-W3.6-LS5.3-RD", (4.8, 42.7), ROT["down"], "SMBJ28A",
      {1: "VIN_P", 2: "GND"}, lcsc="C178227", local=True, crtyd=(-3.65, -2.05, 3.65, 2.05))
for x in (-2.1, -0.6, 0.9):
    via(x, 48.6, "GND")
trk([(-1.1, 46.9), (-1.1, 48.6)], 0.8, "GND"); trk([(-2.1, 48.6), (0.9, 48.6)], 0.6, "GND")
for x in (4.2, 5.4):
    via(x, 47.0, "GND")
trk([(4.8, 45.06), (4.8, 47.0)], 0.8, "GND"); trk([(4.2, 47.0), (5.4, 47.0)], 0.6, "GND")

# ---- Q1/U2: input reverse-polarity ideal diode (LM74700 + 60V N-FET) ----
PDFN_CY = (-1.6, -2.6, 1.6, 1.7)
place("Q1", None, "PDFN3333-8_L3.1-W3.2-P0.65-LS3.4-BL_1", (7.0, 52.0), ROT["up"],
      "DMT6007LFGQ-7", {1: "VIN_RAW", 2: "VIN_RAW", 3: "VIN_RAW", 4: "GATE1", 5: "VIN_P"},
      lcsc="C5624212", local=True, crtyd=PDFN_CY)
SOT_CY = (-1.7, -1.75, 1.7, 1.75)
# LM74700 DBV: 1 VCAP 2 GND 3 EN 4 CATHODE 5 GATE 6 ANODE. EN tied to CATHODE (see README).
place("U2", None, "SOT-23-6_L2.9-W1.6-P0.95-LS2.8-BL", (8.08, 48.4), 180, "LM74700QDBVRQ1",
      {1: "VCAP1", 2: "GND", 3: "VIN_P", 4: "VIN_P", 5: "GATE1", 6: "VIN_RAW"},
      lcsc="C2941042", local=True, crtyd=SOT_CY)
place2("C14", *C0402, (9.03, 45.5), "up", "VCAP1", "VIN_RAW", "100nF 25V X7R 0402")
trk([(9.03, 46.8), (9.03, 45.98)], 0.25, "VCAP1")
trk([(9.03, 45.02), (10.1, 45.02), (10.1, 49.55), (9.1, 49.55)], 0.3, "VIN_RAW")
trk([(8.08, 50.0), (8.08, 51.02)], 0.25, "GATE1")
trk([(7.13, 49.9), (7.13, 50.9)], 0.3, "VIN_P")
trk([(7.13, 47.7), (7.13, 49.1)], 0.25, "VIN_P")        # EN -> CATHODE under the body
trk([(8.08, 46.8), (8.08, 46.0)], 0.25, "GND"); via(8.08, 46.0, "GND")
place2("C15", *C0603, (10.4, 53.0), "down", "VIN_RAW", "GND", "100nF 50V X7R 0603")
trk([(10.4, 53.775), (10.4, 54.9)], 0.3, "GND"); via(10.4, 54.9, "GND")

# ---- J3 XT30 input. Pins face +x, mating face overhangs the left board edge by 0.55mm ----
J3 = place("J3", None, "CONN-TH_XT30PW-M", (3.0, 64.5), -90, "XT30PW-M",
           {1: "VIN_RAW", 2: "GND", 3: "GND", 4: "GND"}, lcsc="C431092", local=True,
           crtyd=(-6.9, -6.5, 6.9, 8.3))

# ---- Q2/U3: output OR-ing ideal diode (VOUT_S -> 5V rail) ----
place("Q2", None, "PDFN3333-8_L3.1-W3.2-P0.65-LS3.4-BL_1", (14.85, 60.0), 180,
      "DMT6007LFGQ-7", {1: "VOUT_S", 2: "VOUT_S", 3: "VOUT_S", 4: "GATE2", 5: "5V"},
      lcsc="C5624212", local=True, crtyd=PDFN_CY)
place("U3", None, "SOT-23-6_L2.9-W1.6-P0.95-LS2.8-BL", (11.45, 59.5), 270, "LM74700QDBVRQ1",
      {1: "VCAP2", 2: "GND", 3: "5V", 4: "5V", 5: "GATE2", 6: "VOUT_S"},
      lcsc="C2941042", local=True, crtyd=SOT_CY)
place2("C16", *C0402, (11.45, 57.3), "right", "VCAP2", "VOUT_S", "100nF 25V X7R 0402")
trk([(10.3, 58.2), (10.3, 57.3), (10.97, 57.3)], 0.25, "VCAP2")
trk([(12.6, 58.2), (12.6, 57.3), (11.93, 57.3)], 0.3, "VOUT_S")
trk([(12.6, 57.3), (14.0, 57.3)], 0.4, "VOUT_S")
trk([(12.6, 59.5), (13.87, 58.92)], 0.2, "GATE2")
trk([(12.6, 60.45), (13.8, 60.45)], 0.4, "5V")
trk([(10.5, 60.45), (12.4, 60.45)], 0.25, "5V")          # EN -> CATHODE under the body
via(11.45, 59.5, "GND")
trk([(10.5, 59.5), (11.45, 59.5)], 0.25, "GND")
place2("C17", *C1210, (14.3, 66.5), "down", "5V", "GND", "22uF 25V X5R 1210")
for x, y in ((13.0, 63.2), (14.0, 63.2), (15.0, 63.2), (16.0, 63.2), (13.5, 64.0), (15.5, 64.0)):
    via(x, y, "5V")
for x in (13.3, 15.3):
    via(x, 69.3, "GND")
trk([(14.3, 68.0), (14.3, 69.3)], 0.6, "GND"); trk([(13.3, 69.3), (15.3, 69.3)], 0.5, "GND")

# ---- 5V indicator ----
place2("R8", *R0603, (11.2, 64.4), "down", "5V", "LED_A", "2.2k 0603")
place2("D2", *LED0603, (11.2, 67.5), "up", "GND", "LED_A", "green LED 0603")
trk([(11.2, 63.58), (12.6, 63.58)], 0.3, "5V")
trk([(11.2, 65.22), (11.2, 66.71)], 0.25, "LED_A")
trk([(11.2, 68.29), (11.2, 69.6)], 0.3, "GND"); via(11.2, 69.6, "GND")

# ---- Extra GND stitching in the strip (F.Cu GND <-> In1/In2 GND) ----
for x, y in ((-3.5, 19.0), (-3.5, 23.0), (-1.5, 21.0), (0.5, 19.0), (0.5, 23.5), (-3.5, 27.0),
             (-2.0, 30.5), (13.0, 18.5), (15.5, 18.5), (13.0, 21.5), (15.5, 21.5), (15.2, 25.0),
             (15.5, 29.5), (7.0, 40.0), (9.0, 41.5), (11.5, 40.0), (11.5, 43.0), (7.5, 43.5),
             (12.3, 50.5), (12.3, 54.0), (10.5, 70.8), (13.0, 71.3), (16.0, 71.3)):
    via(x, y, "GND")

# ---- Copper zones -------------------------------------------------------------------
# priority: specific power nets (5) > strip planes (1) > full-board planes (0)
zone("VIN_P", pcbnew.F_Cu, [(-4.0, 32.2), (5.25, 32.2), (5.25, 38.3), (6.5, 38.3), (6.5, 50.4),
                            (7.3, 50.4), (7.3, 53.6), (4.3, 53.6), (4.3, 57.4), (-4.0, 57.4)], 5)
zone("VOUT_REG", pcbnew.F_Cu, rect(6.75, 32.2, 16.2, 34.8), 5)
zone("VOUT_S", pcbnew.F_Cu, rect(13.7, 36.2, 16.4, 59.2), 5)
zone("VIN_RAW", pcbnew.F_Cu, [(7.6, 49.9), (11.0, 49.9), (11.0, 56.0), (9.35, 56.4), (9.35, 63.5),
                              (6.6, 63.5), (6.6, 56.4), (7.6, 55.8)], 5)
zone("5V", pcbnew.F_Cu, rect(12.4, 59.9, 16.2, 66.2), 5)

bx0p, by0p, bx1p, by1p = bx0 + 0.3, by0 + 0.3, bx1 - 0.3, by1 - 0.3
# F.Cu/B.Cu stay bare outside the power strip (as on the original board): F.Cu copper
# only exists where the SMD parts are (x < 17), B.Cu has no copper at all beyond THT pads.
zone("GND", pcbnew.F_Cu, rect(bx0p, by0p, 17.0, by1p), 0, clearance=0.3, full=False)

# Power distribution is on the inner layers, in the corridors the GPIO bus leaves free:
#   above the lane band  (y < 26.4, only J2's own pads there)
#   below the lane band  (y > 63.1 west of J1, only mounting holes there)
#   a column at x 16.2..18.3 (between the strip parts and H_EXP1/3, H_PANEL1/3/5)
# In2 carries 5V, In1 carries GND directly underneath it (tight loop, low inductance).
# Fill clearance carves around every hole/pad/via automatically.
zone("5V", pcbnew.In2_Cu, [
    (16.2, by0p), (28.3, by0p), (28.3, 18.45),          # top band -> J2 pins 2, 4
    (18.3, 18.45), (18.3, 63.2),                         # column down the strip edge
    (103.6, 63.2), (103.6, 69.3), (108.4, 69.3),         # bottom band -> J1 pins 2, 4
    (108.4, by1p), (101.8, by1p), (101.8, 67.6),
    (12.4, 67.6), (12.4, 62.6), (16.2, 62.6)], 5,       # Q2 drain vias
    clearance=0.3, full=True)   # solid: J2 pin 4 is too close to pin 6 for 2 thermal spokes
zone("GND", pcbnew.In1_Cu, [
    (bx0p, by0p), (66.4, by0p), (66.4, 17.6),               # band over J2's even row
    (18.3, 17.6), (18.3, 63.2),
    (103.6, 63.2), (103.6, 71.3), (146.2, 71.3),            # band under J1's even row
    (146.2, by1p), (bx0p, by1p)], 1, clearance=0.3, full=False)
# Every even-row GND pin (6, 14, 20, 30, 34) on both headers gets an In1 stub into its
# band. The odd-row GND pins (9, 25, 39) sit behind the other row and stay tied only
# through the Pi / HAT, same as on the original board.
for fp, band_y in ((j2, 17.2), (j1, 71.8)):
    for pin in (6, 14, 20, 30, 34):
        p = fp.FindPadByNumber(str(pin)).GetPosition()
        make_track(p, pcbnew.VECTOR2I(p.x, MM(band_y)), pcbnew.In1_Cu, MM(0.6), nets["GND"])
zone("GND", pcbnew.In2_Cu, rect(bx0p, by0p, 15.9, by1p), 1, clearance=0.3, full=False)

# Keep plane copper away from every mounting hole so a screw head / standoff can't
# rub through the mask onto 5V or GND.
for fp in list(board.GetFootprints()):
    if fp.GetReference().startswith("H_"):
        c = fp.GetPosition()
        cx, cy = pcbnew.ToMM(c.x), pcbnew.ToMM(c.y)
        r = 3.4 if fp.GetReference().startswith("H_PANEL") else 3.0
        k = pcbnew.ZONE(board)
        k.SetIsRuleArea(True)
        k.SetDoNotAllowZoneFills(True)
        k.SetDoNotAllowTracks(False)
        k.SetDoNotAllowVias(False)
        k.SetDoNotAllowPads(False)
        k.SetDoNotAllowFootprints(False)
        ls = pcbnew.LSET()
        ls.AddLayer(pcbnew.F_Cu)
        ls.AddLayer(pcbnew.B_Cu)
        k.SetLayerSet(ls)
        ol = k.Outline()
        ol.NewOutline()
        for i in range(24):
            a = 2 * math.pi * i / 24
            ol.Append(MM(cx + r * math.cos(a)), MM(cy + r * math.sin(a)))
        board.Add(k)

# ---- Silkscreen for the power strip ----
add_text("VIN 5-24V", (4.0, 56.3), size_mm=0.9)
add_text("+", (8.0, 59.9), size_mm=1.2)
add_text("-", (8.0, 69.2), size_mm=1.2)
add_text("PWR", (11.2, 70.9), size_mm=0.7)
add_text("5V2 BUCK-BOOST", (-3.8, 17.6), size_mm=0.7)

# ---- Fill and save ----
filler = pcbnew.ZONE_FILLER(board)
filler.Fill(board.Zones())
pcbnew.SaveBoard(OUT, board)
print("Saved:", OUT)
print("Board size: %.2f x %.2f mm" % (bx1 - bx0, by1 - by0))

# ---- Verification printout: every PSU pad and its net ----
for ref, value, name, lcsc, fp in bom:
    pads = sorted(fp.Pads(), key=lambda p: (len(p.GetNumber()), p.GetNumber()))
    desc = ", ".join("%s@(%.2f,%.2f)=%s" % (p.GetNumber(), pcbnew.ToMM(p.GetPosition().x),
                                              pcbnew.ToMM(p.GetPosition().y), p.GetNetname() or "-")
                     for p in pads)
    print(f"{ref:4s} {value:34s} {desc}")

# ---- JLCPCB BOM + CPL for the power parts (J1/J2 lines kept from the original) ----
import csv
import os
os.makedirs(PROJ + r"\jlcpcb", exist_ok=True)
groups = {}
for ref, value, name, lcsc, fp in bom:
    groups.setdefault((value, name, lcsc), []).append(ref)
with open(PROJ + r"\jlcpcb\BOM.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["Comment", "Designator", "Footprint", "LCSC Part#"])
    w.writerow(["2x20 2.54mm THT female socket (0.8mm bore, standard height)", "J1",
                "PinSocket_2x20_P2.54mm_Vertical", "SEARCH_NEEDED"])
    w.writerow(["2x20 2.54mm THT male pin header (standard height)", "J2",
                "PinHeader_2x20_P2.54mm_Vertical", "SEARCH_NEEDED"])
    for (value, name, lcsc), refs in sorted(groups.items(), key=lambda kv: kv[1][0]):
        w.writerow([value, ",".join(sorted(refs, key=lambda r: (r[0], int(r[1:])))), name,
                    lcsc])
with open(PROJ + r"\jlcpcb\CPL.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["Designator", "Mid X", "Mid Y", "Layer", "Rotation"])
    for fp in sorted(board.GetFootprints(), key=lambda f: f.GetReference()):
        if fp.GetReference().startswith("H_"):
            continue
        p = fp.GetPosition()
        w.writerow([fp.GetReference(), "%.3fmm" % pcbnew.ToMM(p.x), "%.3fmm" % -pcbnew.ToMM(p.y),
                    "Top", "%g" % (fp.GetOrientationDegrees() % 360)])
print("BOM/CPL written")
