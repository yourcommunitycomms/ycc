# openmanet GPIO relocator + on-board 5-24V power supply

Same board as `../openmanet_gpio_adapter` (holes, J1/J2, inner-layer GPIO bus are
byte-for-byte the same geometry, copied from `build_pcb5.py`) plus a **22mm power
strip on the left edge** that turns any 5-24V input into a regulated 5.2V rail on the
GPIO 5V pins.

Built by `build_power_pcb.py` (KiCad 10 pcbnew scripting, same approach as the
original). Re-run it to regenerate the `.kicad_pcb`, `jlcpcb/BOM.csv` and `jlcpcb/CPL.csv`.

**Board: 165 x 56.5mm, 4 layers** (was 143 x 56.5). New left edge is x = -4.5;
everything else is in the same place.

## What the supply does

```
J3 XT30  ->  Q1+U2 ideal diode  ->  TVS D1 + 47uF bulk  ->  U1 TPS552892 buck-boost
 (VIN_RAW)    (reverse-polarity)       (VIN_P)                 400kHz, 5.19V out
                                                                     |
 GPIO 5V pins <- In2 5V bands  <- Q2+U3 ideal diode <- R7 10mR sense (5A limit)
                                    (OR-ing / anti-backfeed)
```

| Item | Value |
|---|---|
| Input range | ~4.3V to 28V continuous (spec'd for 5-24V). Below ~4.1V the regulator's UVLO holds it off |
| Output | 5.19V at the regulator, ~5.17V on the rail after the OR-ing FET |
| Output current | 5A hard limit (50mV / 10mR); comfortably 3A continuous for a Pi 4 plus its HAT |
| Reverse polarity | Blocked by Q1/U2 (up to -28V); nothing downstream sees it |
| Surge | SMBJ28A after the reverse-polarity FET (Vbr 31V, clamps ~45V; TPS552892 abs max is 40V) |
| Backfeed | Q2/U3 stop a higher 5V source on the rail (for example the battery board) from pushing current back into this regulator |
| Indicator | Green LED D2 on the 5V rail |

### Why buck-boost
With a 5V input, a buck converter can't make 5.1V; it just passes the input through,
minus losses. The TPS552892 is a 4-switch buck-boost with all FETs internal, and it
regulates seamlessly as the input crosses 5V. Unlike the TPS55288 it needs no I2C;
output is set by a resistor divider.

### Power distribution (fixes a latent issue in the original)
In the original board, 5V and GND only went through the 0.25mm inner-layer lanes (pins
2/4 and the GND pins), which is about 0.3 ohm per lane and would cook at Pi 4 current. Now:
- **Top and bottom layers stay bare** across the original board area, as before. The
  only outer copper beyond THT pads and the original bus vias is F.Cu inside the
  power strip (x < 17), because the SMD parts have to sit on an outer layer.
  **B.Cu has no copper anywhere** except THT pads/vias.
- **5V is on In2** in the corridors the GPIO bus leaves free: a column down the strip
  edge (x 16.2-18.3), a top band (y < 18.4) into J2 pins 2/4, and a ~4mm band *below*
  the lane band (y 63.2-67.6, carved around the mounting holes) into J1 pins 2/4.
- **GND is on In1 directly under it**: the whole strip, the same bottom band (wider,
  down to the board edge), a band over J2's even row, and a band under J1's even row.
  Even-row GND pins 6/14/20/30/34 of both headers stub into those bands.
- The 40-lane GPIO bus (In1 escape stubs, In2 lanes) is unchanged.
- Estimated supply loop resistance, strip to Pi: ~45mR with JLC's default 0.5oz
  inner copper (about 0.13V drop at 3A), ~23mR with 1oz inner (about 0.07V). The Pi
  sees about 5.1V at typical load either way. **Choose 1oz inner copper** if the option
  is cheap; see the ordering guide.

## Things you should know / decide

1. **Battery board on the same 5V rail.** If the battery board also drives GPIO 5V,
   whichever source is higher supplies the load. Q2/U3 protect *this* regulator from
   backfeed, but nothing on this board can protect the battery board's output. If
   its converter can't tolerate being held at 5.17V, only fit one source (or cut its
   5V pin).
2. **XT30 polarity.** Silkscreen marks pad 1 as `+` (LCSC footprint's pin 1). Check it
   against your cable before first power. If it's wrong, reverse protection means
   nothing is damaged; the board just won't turn on.
3. **Back-powering the Pi through GPIO** bypasses the Pi's own USB-C input protection.
   That's standard for HAT supplies, but don't plug USB-C power in at the same time.
4. **Loop compensation** (R3 4.99k / C7 22nF / C6 100pF) was calculated from the
   datasheet equations for ~9kHz crossover, worst case 4.5V in / 3A. It's a sound
   starting point but hasn't been bench-tested. Check a load step on the first board.
5. **EN pins of both LM74700s tie to their own CATHODE**, not ANODE. That keeps EN
   within its abs-max during a reverse-polarity input. It also means the FET's body
   diode carries the first few microseconds of startup, as TI's startup description
   already assumes.

## Design verification status

- `kicad-cli pcb drc --severity-all`: **0 errors**. The remaining warnings are all
  silkscreen (text near edges/pads).
- 4 "unconnected" items, all by design, same class as the original's: the two 3V3
  pins, and the odd-row GND pins (J2 pin 9, J1 pins 25/39). These sit behind the
  other pin row and are tied together inside the Pi/HAT, not on this board.
- `openmanet_power_adapter.kicad_dru` relaxes clearance to 0.15mm **only for U1's own
  pads**. TI's recommended RYQ land pattern has 0.18mm pad gaps; JLCPCB's 4-layer
  capability is 0.09mm.
- Footprints for U1/U2/U3/Q1/Q2/D1/L1/J3 come from LCSC/JLC's own library (via
  easyeda2kicad), so they match what JLC places. U1's pads were cross-checked against
  TI's RYQ0021A land pattern (21 pads, 0.25/0.33mm widths, 3.4mm strips, 4.08/4.8mm
  spans). The LM74700 pinout was checked against TI's DBV pin table.
- No schematic (`.kicad_sch`). The netlist is fully defined in `build_power_pcb.py`,
  and running it prints every pad and its net.

## Files

- `build_power_pcb.py` - generates everything
- `openmanet_power_adapter.kicad_pcb/.kicad_pro/.kicad_dru` - the board
- `openmanet_power.pretty/` - the 6 LCSC footprints used (courtyards redrawn at build time)
- `jlcpcb/` - Gerbers zip, BOM, CPL, ordering guide
- `preview_top.pdf` - F.Cu + silk + outline
