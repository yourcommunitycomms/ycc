# openmanet GPIO relocator adapter - full design spec

Paste this whole document into a fresh conversation (with KiCad + kicad-cli
available) to rebuild this board from scratch if the project files are lost.
It's written to be self-contained - no need to reference prior chat history.

## 1. What this board is for

A Raspberry Pi 4 needs to connect to a stack of two boards (a battery board,
then a transmitter board stacked on top of it) via the standard 40-pin GPIO
header, but the full stack (Pi4 + battery + transmitter, one on top of the
other) is too tall for the target enclosure. This adapter relocates that
connection so the Pi4 and the battery+transmitter pair sit side by side
(coplanar) on top of a single carrier board, instead of stacked vertically.

## 2. The mechanical trick: Pi4 mounts chip-side DOWN

A Pi4's GPIO header only ever points away from its own component (chip) side
- that's fixed, can't be changed. For the Pi4 to end up coplanar with the
battery/transmitter stack (both sitting on the SAME side of this adapter,
at the same height), the Pi4 must be mounted **upside down (chip-side
facing down, toward this adapter)**, with its male header plugging DOWN into
a female socket on this adapter's top surface. The battery board mounts
normally (right-side up), its female socket receiving a male header this
adapter provides, also pointing up from the same top surface.

**Consequence**: Pi4's USB/Ethernet/HDMI/audio/SD-card all end up facing
DOWN toward whatever this board is mounted to. The enclosure/panel below
needs cutouts for cable access there. (Confirmed acceptable by the project
owner - not an oversight.)

## 3. Connectors

- **J2** - "expansion" side, 2x20 THT **male** pin header, standard
  orientation (not flipped). KiCad footprint:
  `Connector_PinHeader_2.54mm:PinHeader_2x20_P2.54mm_Vertical`. The battery
  board's female socket plugs onto this from above; the transmitter board
  still stacks on the battery board as it always did (that part is
  unchanged - only the Pi4 connection moved).
- **J1** - "Pi4" side, 2x20 THT **female** socket, MIRRORED (see below).
  KiCad footprint: `Connector_PinSocket_2.54mm:PinSocket_2x20_P2.54mm_Vertical`.
  Pi4's own male header plugs down into this.

### Pin mapping (both connectors)

Standard Raspberry Pi 40-pin GPIO header, pin 1 = 3V3 (top-left when viewed
normally). Net assignment is done **by pad number**, never by physical
position, so mirroring/repositioning a footprint never touches which signal
goes where:

```
1:3V3  2:5V  3:GPIO02_SDA1  4:5V  5:GPIO03_SCL1  6:GND
7:GPIO04_GPCLK0  8:GPIO14_TXD  9:GND  10:GPIO15_RXD
11:GPIO17  12:GPIO18_PCM_CLK_PWM0  13:GPIO27  14:GND  15:GPIO22
16:GPIO23  17:3V3  18:GPIO24  19:GPIO10_MOSI0  20:GND
21:GPIO09_MISO0  22:GPIO25  23:GPIO11_SCLK0  24:GPIO08_CE0  25:GND
26:GPIO07_CE1  27:ID_SD  28:ID_SC  29:GPIO05  30:GND
31:GPIO06  32:GPIO12_PWM0  33:GPIO13_PWM1  34:GND  35:GPIO19_MISO1
36:GPIO16  37:GPIO26  38:GPIO20_MOSI1  39:GND  40:GPIO21_SCLK1
```

Pin N on J1 = pin N on J2 in terms of Pi4 signal identity (a straight,
non-mirrored electrical pass-through) - only J1's *physical pad positions*
are mirrored to match the flipped Pi4, the net mapping isn't.

## 4. Coordinate system and all hole/header positions (mm)

Origin is arbitrary; these are the actual absolute coordinates used.

**Official spec facts** (verified against the Raspberry Pi HAT mechanical
spec, and independently cross-checked against a second official source -
see section 7): mounting holes form a 58mm x 49mm rectangle, 2.75mm drill,
each hole 3.5mm from its nearest board edge on a compliant HAT board. The
GPIO header's pin 1 sits offset **(4.88, 1.28)mm** from the nearest corner
hole, with pin pitch 2.54mm in both directions (2 rows x 20 columns).

**Expansion zone** (anchor `HAT_H1` = (20, 20)):
- H_EXP1 (20, 20), H_EXP2 (78, 20), H_EXP3 (20, 69), H_EXP4 (78, 69) -
  all 4 present, standard 58x49mm pattern, 2.7mm/M2.5 mounting holes.
- J2 pin 1 at (24.88, 21.28) = HAT_H1 + (4.88, 1.28), rotation 90 degrees.
  (Rotation convention: at 90 degrees using KiCad's current PinHeader/
  PinSocket 2.54mm footprints, pin-pair index increases toward +X and pin 2
  of each pair lands +2.54mm in +Y from pin 1 for PinHeader specifically -
  verify this empirically for your KiCad version before trusting it blindly,
  footprint library conventions can change between versions - see section 8.)

**Pi4 zone** (anchor `PI_H1` = (100, 20)):
- H_PI1 (100, 20), H_PI2 (158, 20), H_PI3 (100, 69), H_PI4 (158, 69) -
  all 4 present, same pattern as expansion zone.
- J1 pin 1 at (104.88, 67.72) = PI_H1 + (4.88, 49 - 1.28) - i.e. offset from
  the FAR row (H_PI3/H_PI4, y=69) instead of the near row, because Pi4 is
  flipped. Rotation 90 degrees, SAME footprint/rotation as J2's (not a
  different rotation value) - but with each even-numbered pad's Y
  individually moved to +2.54mm from its odd partner (the DEFAULT,
  unmirrored per-pad pattern the footprint library already gives at
  rotation 90 - no additional per-pad correction needed; see section 8 for
  why this was initially miscalculated and how it was verified).

**Panel mounting holes** (M3, 3.2mm drill, all NPTH/no copper land), 8 total:
- Left column (x=21): H_PANEL1 (21, 27), H_PANEL3 (21, 44.5), H_PANEL5
  (21, 62) - top/middle/bottom, 17.5mm spacing, centred on y=44.5 (the
  midline between row 1 y=20 and row 2 y=69).
- Right column (x=157): H_PANEL2 (157, 27), H_PANEL4 (157, 44.5), H_PANEL6
  (157, 62) - mirrors the left column.
- Gap bridge: H_PANEL7 (89, 20) - midway between H_EXP2 and H_PI1.
  H_PANEL8 (89, 69) - midway between H_EXP4 and H_PI3.
- x=21/x=157 were chosen because they're clear of ALL escape routing at any
  Y (see section 5) - going further inward toward the centre would need
  routing rework (some bus traces would need rerouting around the new
  holes); x=89 (the gap holes) works because y=20/69 sit outside the routed
  Y-band entirely.

**Board outline** (rectangle, `Edge.Cuts`): 143mm x 56.5mm.
- Left edge x = 20 - 2.5 = 17.5 (H_EXP1's hole, minus edge clearance)
- Right edge x = 158 + 2.5 = 160.5 (H_PI2/H_PI4, plus edge clearance)
- Top edge y = 18.74 - 2.5 = 16.24 (J2's own even-pin row, which sticks out
  1.28mm past the row-1 holes - closer to the edge than the holes
  themselves, so IT sets the top edge, not the holes)
- Bottom edge y = 70.26 + 2.5 = 72.76 (J1's pin-2 row, similarly the
  closest feature to the bottom edge, past the row-2 holes)
- 2.5mm edge margin = roughly pad/hole radius (1.35-1.6mm) + a bit of
  clearance, tuned to just clear KiCad's default 0.5mm copper-to-edge DRC
  rule - not a round-number choice, it's the minimum that passes DRC for
  the closest feature on each edge.

## 5. Routing

**4-layer board. All 40 signal traces live on the two INNER layers only**
(`In1.Cu` for pad escape stubs, `In2.Cu` for the long run between headers) -
zero traces on `F.Cu`/`B.Cu` (pads and silkscreen only there, so the outer
surfaces stay fully protected/bare).

The routing problem: pins are on a 2.54mm grid with 1.7mm-diameter pads,
leaving ~0.84mm clear between neighbours - not enough room to route 40
traces straight out without one grazing a neighbour's pad. Solution used
("bus escape" pattern):

1. Each of the 40 pins gets a unique horizontal **lane** on `In2.Cu`, in
   the open Y-band between the two header rows: `LANE_Y0 = 26.5`,
   `LANE_STEP = 0.93`, so pin N's lane is at `26.5 + (N-1) * 0.93`.
2. For each connector, one row of the pin-pair is closer to the lane band,
   one is farther. The nearer row escapes with a straight stub (pad
   straight to its lane, `In1.Cu`). The farther row needs a sideways jog of
   **1.27mm** (`FAR_NUDGE`) right at the pad, BEFORE going to its lane -
   this is the exact midpoint of the 2.54mm pair pitch, chosen because it's
   the maximum offset that clears BOTH its own pair-mate's pad AND the next
   pair's pad (each ~1.2mm away at that offset) - this specific 1.27mm
   value is load-bearing, don't round it.
   - For J2 (unflipped): even-numbered pins are the "far" row.
   - For J1 (flipped): even-numbered pins are ALSO the "far" row (this
     flips relative to what you'd naively expect from the geometry -
     verify empirically, don't assume).
3. A via connects each stub (`In1.Cu`) to its lane (`In2.Cu`) at the bend
   point.
4. The long bus segment for pin N runs on `In2.Cu` from J2's bend point to
   J1's bend point, at pin N's lane Y.

Track widths: 0.25mm for everything (signal AND power nets) - deliberately
kept equal because the 2.54mm pair pitch doesn't leave room for wider power
traces without violating the pad-clearance math in step 2. Via: 0.6mm pad,
0.3mm drill.

**Important limitation discovered while adding panel holes**: the escape
vias/stubs aren't just clustered near each header - they're spread across
nearly the ENTIRE width of each header (J2 side: ~x=21-76, J1 side:
~x=104-154). Only the narrow strips outside that (before x=21ish, after
x=154ish, or in the ~15mm gap between the two zones at y=20/69 specifically)
are genuinely clear of routing without rework.

## 6. Silkscreen / labelling

Minimal, per explicit request - just:
- "EXPANSION SIDE (male)" near (26, 24.6)
- "PI SIDE (female)" near (106, 24.6)
- All 16 mounting hole reference designators (H_EXP1-4, H_PI1-4,
  H_PANEL1-8) visible on the silkscreen, so specific holes can be
  identified and referenced precisely (e.g. "remove H_PANEL2") without
  ambiguity.

J1's own footprint-inherited silkscreen outline/courtyard was DELETED and
replaced with a custom rectangle drawn from J1's actual (post-mirroring) pad
positions - the stock footprint graphics are drawn for the unmirrored pad
layout and don't move when you reposition individual pads (see section 8).

## 7. Spec sources (for re-verification)

- Official Raspberry Pi HAT mechanical spec (PDF):
  `https://raw.githubusercontent.com/raspberrypi/hats/master/hat-board-mechanical.pdf`
  - Confirms: 65x56mm or 65x56.5mm board, 3mm corner radius, 4x M2.5 holes
    at 58x49mm pattern inset 3.5mm from edges, drilled to 2.75mm +/-0.05mm.
- Official KiCad "Raspberry Pi HAT" template project (gives the exact
  GPIO-header-to-mounting-hole offset as raw coordinates, more reliable
  than trying to read dimension lines off the PDF drawing by eye):
  `https://raw.githubusercontent.com/KiCad/kicad-templates/master/Projects/raspberrypi_hat/raspberrypi_hat.kicad_pcb`
  - Female GPIO socket module position vs. its nearest mounting hole gives
    offset (4.88, 1.28)mm (after accounting for that file's own rotation,
    which used a different KiCad library version's footprint convention
    than current KiCad - don't reuse its rotation value directly, only the
    offset).
- Independent cross-check: KiCad's own Raspberry Pi Zero footprint (combines
  mounting holes AND GPIO header in one file):
  `https://raw.githubusercontent.com/KiCad/kicad-footprints/master/Module.pretty/Raspberry_Pi_Zero_Socketed_THT_FaceDown_MountingHoles.kicad_mod`
  - Gives offset (1.27, 4.87)mm - same value as above with X/Y swapped
    (different local orientation convention in that file). Two independent
    official sources agreeing to within 0.01mm confirms the offset value.
  - Note: Pi Zero's own mounting hole RECTANGLE is a different, smaller,
    non-HAT-standard size - only the header-to-nearest-hole OFFSET is
    comparable, not the overall hole pattern.

## 8. Pitfalls hit while building this the first time (avoid repeating them)

- **KiCad footprint library rotation conventions can differ between KiCad
  versions.** The official 2018-era HAT template used rotation=270 for the
  female GPIO socket; the SAME relative offset with current KiCad 10's
  bundled footprint needed rotation=90 to land in the same physical
  place - the footprint's internal pad layout changed at some point.
  **Verify empirically** (place the footprint, print actual pad positions,
  compare to expectation) rather than trusting an old file's rotation value.
- **`Footprint.Flip()` crashed the pcbnew Python API on this KiCad 10
  install** (access violation) - don't rely on it. Mirroring a footprint
  for the Pi4-flip trick was done by directly repositioning individual pads
  (`pad.SetPosition(...)`) instead, which works but has a side effect: the
  footprint's inherited silkscreen/courtyard graphics do NOT move with the
  pads (they're separate objects tied to the original, un-mirrored layout).
  **You must manually strip the stale graphics and redraw a correct
  outline from the actual post-move pad positions**, or the board will
  visually show pads outside/misaligned with their own silkscreen box even
  though the pads themselves are electrically correct.
- **A simple 1:1 escape-per-pin routing scheme will short circuit itself**
  if you don't account for the row structure: pins 1&2 (and every pair)
  share the same X after rotation, differing only by 2.54mm in Y - a naive
  "route straight up to a unique lane" approach makes the farther pin's
  route pass directly through its own pair-mate's pad. Needed the
  near/far-row jog scheme in section 5 to avoid this. Verify via
  `kicad-cli pcb drc --severity-all` after routing, not just a visual check.
- **Always render a visual (PDF export via kicad-cli, read with the Read
  tool) before declaring geometry correct.** Pure coordinate math was wrong
  more than once in ways that only became obvious on an actual render -
  `kicad-cli pcb export pdf --layers "F.SilkS,In1.Cu,In2.Cu,Edge.Cuts" --output preview.pdf board.kicad_pcb`
  then read `preview.pdf` directly.
- **`pdftoppm`/poppler isn't installed on this Windows machine**, so the
  Read tool's PDF page-rendering (multi-page PDFs, or the `pages=` param)
  fails - only single-page PDFs read directly without that param worked
  reliably for viewing rasterized drawings.
- Board margin/outline should be computed from the ACTUAL closest physical
  feature per edge (which changed several times as the design evolved -
  a header pad row, a mounting hole, or a panel hole, depending on the
  current layout), not a fixed round-number margin - re-derive this fresh
  each time the layout changes rather than reusing an old formula.

## 9. Toolchain used

KiCad 10 (`C:\Program Files\KiCad\10.0\`), built entirely via the `pcbnew`
Python scripting API (`C:\Program Files\KiCad\10.0\bin\python.exe`), NOT
hand-drawn in the GUI and NOT hand-written KiCad file format text. Add
`C:\Program Files\KiCad\10.0\bin` to PATH before running the Python script
(pcbnew's native DLLs won't resolve otherwise, causing an import-time
crash). Verify with `kicad-cli pcb drc --severity-all --format json` after
every change, and treat anything other than 0 errors (warnings are OK) as
a real problem to fix before moving on.
