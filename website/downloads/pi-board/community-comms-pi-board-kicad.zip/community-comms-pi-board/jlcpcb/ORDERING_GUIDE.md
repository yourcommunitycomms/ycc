# Ordering this board from JLCPCB (fab + assembly)

## Files in this folder

- `openmanet_gpio_adapter_gerbers.zip` - Gerbers + drill file, ready to upload as-is.
- `BOM.csv` - Bill of materials (J1, J2 only - mounting holes aren't parts).
- `CPL.csv` - Component placement/position file, for the assembly (PCBA) step.

## Step 1: PCB fabrication quote

1. Go to jlcpcb.com and click "Instant quote" / "Order Now".
2. Upload `openmanet_gpio_adapter_gerbers.zip` directly - JLCPCB auto-detects
   the outline, layer count, and drill file from it.
3. Confirm these settings match the design (JLCPCB should auto-fill most, but
   check):
   - **Layers: 4**
   - **Board thickness**: 1.6mm is the standard default and works fine here -
     nothing in this design requires a different thickness.
   - **Via covering/tenting**: default (tented) is fine.
   - Everything else (surface finish, copper weight, colour) is your choice -
     doesn't affect this design's function.
4. Get the quote, add to cart.

## Step 2: Assembly (PCBA) - "parts pre-soldered"

This is where it gets a bit more involved than a typical SMD board, because
**this design has only 2 through-hole (THT) parts and zero SMD parts** - J1
(female socket) and J2 (male header), both 2x20, 2.54mm pitch.

1. On the same order page, enable "PCB Assembly" (JLCPCB calls it PCBA).
2. Choose which side gets assembled - **both J1 and J2 are on the top side**
   in this design (see `CPL.csv`, "Side" column = top for both).
3. Upload `BOM.csv` and `CPL.csv` when prompted.
4. **You'll need to pick the actual parts** - I've left `LCSC Part#` as
   `SEARCH_NEEDED` in the BOM because I can't browse JLCPCB's live parts
   catalog to hand you an exact, in-stock part number. In JLCPCB's parts
   selection step, search their catalog for:
   - J1: "2x20 header socket 2.54mm" (female, THT) - e.g. Pin Socket, 40 pos,
     2 rows, 2.54mm pitch, THT.
   - J2: "2x20 pin header 2.54mm" (male, THT) - Pin Header, 40 pos, 2 rows,
     2.54mm pitch, THT, straight.
   - Match the footprint shown against `PinSocket_2x20_P2.54mm_Vertical` /
     `PinHeader_2x20_P2.54mm_Vertical` - standard 0.64mm square pin, THT,
     straight, not right-angle.

## Important things to check before you commit

- **THT assembly availability/cost**: JLCPCB's assembly line is primarily
  built around SMD (reflow) parts. THT parts (like these headers) are
  assembled separately (wave solder or hand solder) and this can mean extra
  cost, a minimum order quantity, or in some cases isn't offered at all for a
  THT-only board depending on their current process capability - **I can't
  verify JLCPCB's current policy on this from here since it changes over
  time. Check directly on their site when you get to the parts-selection step,
  or ask their live chat/support before paying** if it's not clearly offered.
- **Mounting holes need no BOM entry** - they're plain drilled holes (NPTH),
  not parts, and won't appear in the parts-selection step.
- If JLCPCB's PCBA doesn't support this (THT-only, low quantity), the
  fallback is: order the bare PCB only (Step 1), then hand-solder J1/J2
  yourself - it's only 2 parts, 80 pins total, very doable with a
  temperature-controlled iron and about 20-30 minutes.

## Before you submit either order

Please do the visual double-check mentioned earlier in this project (open
the board in KiCad, confirm the Pi4/expansion orientation against your real
hardware) - fabrication and assembly aren't free to redo.
