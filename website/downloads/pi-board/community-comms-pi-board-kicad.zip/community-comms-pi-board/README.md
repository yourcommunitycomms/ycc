# openmanet GPIO relocator adapter

A 4-layer PCB that relocates the Raspberry Pi 4's 40-pin GPIO connection sideways
instead of stacking HATs directly on top of the Pi. Pi4 mounts chip-side DOWN so
it and the expansion (battery/transmitter) boards end up coplanar - side by side
on top of this adapter - instead of stacked at different heights.

Built with KiCad 10 via the pcbnew Python scripting API (not hand-drawn), so
every footprint position, hole, and trace is exact, reproducible coordinates.
**Current version: `build_pcb5.py`.** Earlier scripts (`build_pcb2/3/4.py`) are
kept only as a history of iterations - superseded, don't use them.

**Spec verification**: the 58x49mm/2.75mm-drill mounting hole pattern is taken
directly from the official Raspberry Pi HAT mechanical spec. The GPIO header's
offset from the nearest hole (4.88, 1.28mm) was cross-checked against a SECOND,
independent official source (KiCad's own Raspberry Pi Zero footprint, which
combines holes and header in one file) - it gives (1.27, 4.87mm), the same
value with X/Y swapped due to that file's different local orientation. Two
independent official sources agreeing to within 0.01mm confirms this is right.

**Ordering**: see `jlcpcb/ORDERING_GUIDE.md` for how to get this fabricated
and assembled via JLCPCB, including generated Gerbers, BOM, and CPL files.

## Mechanical model

- **J2** (2x20 male header, normal orientation) - the battery board's female
  socket plugs onto this from above; the transmitter still stacks on the
  battery board as it does today.
- **J1** (2x20 female socket, MIRRORED) - because Pi4 itself is mirrored when
  flipped chip-side-down. Pi4's own male header plugs DOWN into this. Sits near
  the H_PI3/H_PI4 row, with pin 1 close to that row and pin 2 (and every even
  pin) 2.54mm further out, past it - confirmed via DRC that this doesn't
  collide with the H_PI3/H_PI4 holes (non-plated, no copper land).
- Consequence: **Pi4's ports (USB/Ethernet/HDMI/audio/SD card) all face down**
  toward whatever this mounts to - cutouts needed there, confirmed expected.

Net assignment (which pad carries which Pi GPIO signal) is done by **pad
number**, not position, so repositioning pads never touches the electrical
mapping - pad "1" is always Pi4's real pin 1 (3V3). Verified in the build log.

**This is the one part of the design with real electrical stakes if the
geometry is wrong (a misplaced pin could damage a Pi4) - please sanity-check
against a real Pi4 pinout diagram before fabricating.**

## Hole map (all reference labels VISIBLE on the silkscreen)

| Ref | Position (mm) | Notes |
|---|---|---|
| H_EXP1 | (20, 20) | expansion zone, row 1 |
| H_EXP2 | (78, 20) | expansion zone, row 1 |
| H_EXP3 | (20, 69) | expansion zone, row 2 |
| H_EXP4 | (78, 69) | expansion zone, row 2 |
| H_PI1 | (100, 20) | Pi4 zone, row 1 |
| H_PI2 | (158, 20) | Pi4 zone, row 1 |
| H_PI3 | (100, 69) | Pi4 zone, row 2 - J1 pin-1 row sits close to here |
| H_PI4 | (158, 69) | Pi4 zone, row 2 - J1 pin-2 row sits just past here |
| H_PANEL1 | (21, 27) | inside the board, left side, top, M3 |
| H_PANEL3 | (21, 44.5) | inside the board, left side, middle, M3 |
| H_PANEL5 | (21, 62) | inside the board, left side, bottom, M3 |
| H_PANEL2 | (157, 27) | inside the board, right side, top, M3 |
| H_PANEL4 | (157, 44.5) | inside the board, right side, middle, M3 |
| H_PANEL6 | (157, 62) | inside the board, right side, bottom, M3 |
| H_PANEL7 | (89, 20) | bridging the gap, row 1 - midway between H_EXP2/H_PI1, M3 |
| H_PANEL8 | (89, 69) | bridging the gap, row 2 - midway between H_EXP4/H_PI3, M3 |

All 8 zone mounting holes (H_EXP1-4, H_PI1-4) are present - the full official
HAT pattern on both zones.

**8 panel mount points total**: 3 per side (left/right), evenly spaced 17.5mm
apart (top/middle/bottom), centred on y=44.5 (the midline between row-1 y=20
and row-2 y=69) - plus 2 more bridging the gap between the two zones, at
y=20/69 (both outside the lane-routing band, so clear of everything there
regardless of X).

**Why they're only at x=21/157, not further inward toward the centre**: every
GPIO pin has an escape via near its own pad, and those vias are spread across
nearly the *entire* width of each header - roughly x=21-76 for J2's side and
x=104-154 for J1's side, not just clustered near the header itself. The only
corridor genuinely clear of that routing is the narrow strip right at the
board's outer edge, before the via field starts. Moving the panel holes any
further in (e.g. toward the middle gap between the two zones) is possible but
would need several specific bus traces rerouted around each hole - ask if you
want that done; for now they're at the safe maximum.

## Board size

**143mm x 56.5mm** (down from the original 161mm x 72mm). The outline wraps
tightly around the actual physical features - J2's own pads (which stick out
1.28mm past the H_EXP row, closer to the edge than the holes are), the
H_PANEL2/H_PANEL4 holes on the right, the H_PANEL1/H_PANEL3 holes on the left,
and J1's pin-2 row on the bottom - each with just enough clearance to pass
DRC's edge-clearance rule (0.5mm copper-to-edge), not a generic round-number
margin.

## Routing

Straight 1:1 pinout (pin N on J1 = pin N on J2 in Pi4 signal identity - J1's
physical pad positions are mirrored to match the flipped Pi4, the electrical
mapping isn't). All 40 signals on the two INNER layers only: `In1.Cu` (escape
stubs) and `In2.Cu` (the long bus run) - zero traces on `F.Cu`/`B.Cu`.

Each pin escapes to its own lane in the open area between the two header rows.
Only the header row farther from the lane band needs a sideways jog to clear
its own row-mate's pad; the nearer row goes straight in.

## Labelling

Minimal per your request: just "EXPANSION SIDE (male)" and "PI SIDE (female)",
plus the visible H_* reference designators on every mounting hole. The old
longer explanatory note text has been removed from the silkscreen.

## Status

- **DRC: 0 real errors** (`kicad-cli pcb drc`, full severity). A handful of
  cosmetic silkscreen-text-overlap warnings remain now that the board is tight -
  doesn't affect fabrication; easy to nudge labels in the GUI if it bothers you.
- 9 "unconnected items" are expected, not a mistake: 3V3, 5V, and GND each
  appear on multiple physical header pins, each wired straight through
  independently - they're tied together inside the Pi4 itself, so KiCad
  flagging the separate same-named-net islands on this board alone is cosmetic.
- No schematic (.kicad_sch) included yet - ask if you want one generated.
