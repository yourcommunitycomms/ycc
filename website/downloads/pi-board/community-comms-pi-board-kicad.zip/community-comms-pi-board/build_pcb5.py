import os
import pcbnew

MM = pcbnew.FromMM

PINMAP = {
    1: "3V3", 2: "5V", 3: "GPIO02_SDA1", 4: "5V", 5: "GPIO03_SCL1",
    6: "GND", 7: "GPIO04_GPCLK0", 8: "GPIO14_TXD", 9: "GND", 10: "GPIO15_RXD",
    11: "GPIO17", 12: "GPIO18_PCM_CLK_PWM0", 13: "GPIO27", 14: "GND", 15: "GPIO22",
    16: "GPIO23", 17: "3V3", 18: "GPIO24", 19: "GPIO10_MOSI0", 20: "GND",
    21: "GPIO09_MISO0", 22: "GPIO25", 23: "GPIO11_SCLK0", 24: "GPIO08_CE0", 25: "GND",
    26: "GPIO07_CE1", 27: "ID_SD", 28: "ID_SC", 29: "GPIO05", 30: "GND",
    31: "GPIO06", 32: "GPIO12_PWM0", 33: "GPIO13_PWM1", 34: "GND", 35: "GPIO19_MISO1",
    36: "GPIO16", 37: "GPIO26", 38: "GPIO20_MOSI1", 39: "GND", 40: "GPIO21_SCLK1",
}
POWER_NETS = {"3V3", "5V", "GND"}

FP_BASE = r"C:\Program Files\KiCad\10.0\share\kicad\footprints"

HAT_H1 = (20.0, 20.0)
PI_H1 = (100.0, 20.0)
HOLE_DX, HOLE_DY = 58.0, 49.0
HDR_OFFSET = (4.88, 1.28)
ZONE_W, ZONE_H = 65.0, 56.0

board = pcbnew.BOARD()
board.SetCopperLayerCount(4)

nets = {}
for name in set(PINMAP.values()):
    n = pcbnew.NETINFO_ITEM(board, name)
    board.Add(n)
    nets[name] = n

def add_footprint(lib, name, pos_mm, rot_deg):
    fp = pcbnew.FootprintLoad(FP_BASE + "\\" + lib, name)
    fp.SetPosition(pcbnew.VECTOR2I(MM(pos_mm[0]), MM(pos_mm[1])))
    fp.SetOrientationDegrees(rot_deg)
    board.Add(fp)
    return fp

def add_holes(lib_name, origin, offsets, ref_prefix, text_size_mm=1.0):
    for i, (dx, dy) in enumerate(offsets):
        hx, hy = origin[0] + dx, origin[1] + dy
        fp = add_footprint("MountingHole.pretty", lib_name, (hx, hy), 0)
        fp.SetReference(f"{ref_prefix}{i+1}")
        ref = fp.Reference()
        ref.SetVisible(True)
        ref.SetTextSize(pcbnew.VECTOR2I(MM(text_size_mm), MM(text_size_mm)))
        ref.SetTextThickness(MM(text_size_mm * 0.15))
        # Default label placement (above-left of the hole) runs into the tight board
        # edge on row-1 holes - park the label to the side instead.
        ref.SetPosition(pcbnew.VECTOR2I(MM(hx + 2.6), MM(hy)))

hole_offsets = [(0, 0), (HOLE_DX, 0), (0, HOLE_DY), (HOLE_DX, HOLE_DY)]
add_holes("MountingHole_2.7mm_M2.5", PI_H1, hole_offsets, "H_PI")
add_holes("MountingHole_2.7mm_M2.5", HAT_H1, hole_offsets, "H_EXP")

def add_named_holes(lib_name, origin, named_offsets, text_size_mm=1.0):
    for ref_name, (dx, dy) in named_offsets.items():
        hx, hy = origin[0] + dx, origin[1] + dy
        fp = add_footprint("MountingHole.pretty", lib_name, (hx, hy), 0)
        fp.SetReference(ref_name)
        ref = fp.Reference()
        ref.SetVisible(True)
        ref.SetTextSize(pcbnew.VECTOR2I(MM(text_size_mm), MM(text_size_mm)))
        ref.SetTextThickness(MM(text_size_mm * 0.15))
        ref.SetPosition(pcbnew.VECTOR2I(MM(hx + 2.6), MM(hy)))

# ---- J2 (expansion, unflipped): unchanged, near the H_EXP1/H_EXP2 row (y=20) ----
j2_pos = (HAT_H1[0] + HDR_OFFSET[0], HAT_H1[1] + HDR_OFFSET[1])
j2 = add_footprint("Connector_PinHeader_2.54mm.pretty", "PinHeader_2x20_P2.54mm_Vertical", j2_pos, 90)
j2.SetReference("J2")
j2.SetValue("EXPANSION_GPIO_MALE")

# ---- J1 (Pi4, MOUNTED CHIP-SIDE-DOWN): Pi4's own footprint mirrors when flipped, so J1
# must be the mirror image of a normal HAT socket, not just a repositioned copy. Working
# through the geometry (see chat): flip Pi4 about the axis parallel to its long/header edge
# (negate its local Y only) - this keeps pin ordering along the header's length unchanged
# (so USB/Ethernet stays on the same conceptual end as before), but the header now sits
# close to the H_PI3/H_PI4 row (the far one, y=69) instead of H_PI1/H_PI2 (y=20), offset
# by the SAME 1.28mm the official spec uses - just mirrored to the other row. And within
# each pin-pair, the "even" pin now sits 2.54mm on the OTHER side of its "odd" partner.
j1 = add_footprint("Connector_PinSocket_2.54mm.pretty", "PinSocket_2x20_P2.54mm_Vertical", (0, 0), 90)
j1.SetReference("J1")
j1.SetValue("PI4_GPIO_FEMALE_FLIPPED")

J1_ANCHOR_X = PI_H1[0] + HDR_OFFSET[0]
J1_ANCHOR_Y = PI_H1[1] + HOLE_DY - HDR_OFFSET[1]  # = 69 - 1.28 = 67.72, close to the FAR row
j1.SetPosition(pcbnew.VECTOR2I(MM(J1_ANCHOR_X), MM(J1_ANCHOR_Y)))
# TEST: default rot90 placement (even pins +2.54 from odd, no correction) - pin1 stays
# put, pin2 lands "below" pin1 (larger Y). Testing this against DRC/hole clearance
# directly rather than re-deriving the mirror by hand again.

# The footprint's inherited silkscreen/courtyard/fab graphics were drawn for the
# ORIGINAL (unmoved) pad layout - moving pads above did NOT move them, so they now
# show a box that doesn't match where the pads actually are ("not in the mounting
# square"). Pads are what matters electrically, but for a board that's actually
# going to be read visually, that mismatch is a real problem - strip the stale
# graphics and draw a correct outline from the ACTUAL pad positions instead.
for item in list(j1.GraphicalItems()):
    j1.Remove(item)

j1_odd_y = J1_ANCHOR_Y
j1_even_y = J1_ANCHOR_Y + 2.54
j1_x0 = J1_ANCHOR_X - 1.8
j1_x1 = J1_ANCHOR_X + 19 * 2.54 + 1.8
j1_y0 = min(j1_odd_y, j1_even_y) - 1.5
j1_y1 = max(j1_odd_y, j1_even_y) + 1.5

def add_fp_rect(fp, layer, x0, y0, x1, y1, width_mm=0.12):
    shape = pcbnew.PCB_SHAPE(fp)
    shape.SetShape(pcbnew.SHAPE_T_RECT)
    shape.SetStart(pcbnew.VECTOR2I(MM(x0), MM(y0)))
    shape.SetEnd(pcbnew.VECTOR2I(MM(x1), MM(y1)))
    shape.SetLayer(layer)
    shape.SetWidth(MM(width_mm))
    fp.Add(shape)

add_fp_rect(j1, pcbnew.F_SilkS, j1_x0, j1_y0, j1_x1, j1_y1)
j1.Reference().SetPosition(pcbnew.VECTOR2I(MM(J1_ANCHOR_X), MM(j1_y0 - 1.2)))
j1.Value().SetPosition(pcbnew.VECTOR2I(MM(J1_ANCHOR_X), MM(j1_y1 + 1.4)))

for pin, netname in PINMAP.items():
    j1.FindPadByNumber(str(pin)).SetNet(nets[netname])
    j2.FindPadByNumber(str(pin)).SetNet(nets[netname])

# ---- Board outline ----
# H_EXP1/H_EXP3 are gone and the panel holes moved inboard, so the outline no longer
# needs to wrap the old 65x56mm "HAT zone" rectangle - just wrap the ACTUAL leftmost/
# rightmost/topmost/bottommost physical features that remain, with a small edge margin.
EDGE_MARGIN = 2.5  # hole/pad radius (~1.35-1.6mm) plus a bit of clearance

# 6 panel mount points total: 3 per side (top/middle/bottom), spread further apart than
# before, centred on y=44.5 (the midline between row-1 y=20 and row-2 y=69). x=21/157 is
# clear of ALL routing at any Y (nothing routes left of J2 pin1 x=24.88 or right of J1's
# far pin x=154.41), so the only constraint is staying clear of H_EXP1/H_EXP3 (left) and
# H_PI2/H_PI4 (right) themselves, which are only ~1mm away in X - needs >=2.8mm in Y.
PANEL_X_LEFT = 21.0
PANEL_X_RIGHT = 157.0
MID_Y = (HAT_H1[1] + HAT_H1[1] + HOLE_DY) / 2  # = 44.5
PANEL_SPACING = 17.5  # centre-to-centre distance between adjacent holes in each column
panel_holes = {
    "H_PANEL1": (PANEL_X_LEFT, MID_Y - PANEL_SPACING),   # = (21, 27)
    "H_PANEL3": (PANEL_X_LEFT, MID_Y),                   # = (21, 44.5)
    "H_PANEL5": (PANEL_X_LEFT, MID_Y + PANEL_SPACING),   # = (21, 62)
    "H_PANEL2": (PANEL_X_RIGHT, MID_Y - PANEL_SPACING),  # = (157, 27)
    "H_PANEL4": (PANEL_X_RIGHT, MID_Y),                  # = (157, 44.5)
    "H_PANEL6": (PANEL_X_RIGHT, MID_Y + PANEL_SPACING),  # = (157, 62)
}

# 2 more, bridging the gap between the two zones' own mounting holes - exactly midway
# between H_EXP2/H_PI1 (row 1) and between H_EXP4/H_PI3 (row 2). y=20/69 are both
# outside the lane band (26.5-63.17), so this is clear of all routing too.
GAP_X = (HAT_H1[0] + HOLE_DX + PI_H1[0]) / 2  # = (78 + 100) / 2 = 89
panel_holes["H_PANEL7"] = (GAP_X, HAT_H1[1])                # = (89, 20)
panel_holes["H_PANEL8"] = (GAP_X, HAT_H1[1] + HOLE_DY)       # = (89, 69)

# Board edges are now set by the zone mounting holes / header pads again, since the
# panel holes moved off the outer edge.
bx0 = HAT_H1[0] - EDGE_MARGIN                        # leftmost feature: H_EXP1
# Topmost feature is actually J2's own even-pin row (18.74), not the row-1 holes (20) -
# copper needs more edge clearance than a bare NPTH hole does.
J2_TOP_PIN_Y = j2_pos[1] - 2.54
by0 = min(HAT_H1[1], J2_TOP_PIN_Y) - EDGE_MARGIN
bx1 = PI_H1[0] + HOLE_DX + EDGE_MARGIN                # rightmost feature: H_PI2/H_PI4
by1 = max(HAT_H1[1] + HOLE_DY, J1_ANCHOR_Y + 2.54) + EDGE_MARGIN  # row-2 holes vs J1 pin2, whichever is further
for ref_name, pos in panel_holes.items():
    fp = add_footprint("MountingHole.pretty", "MountingHole_3.2mm_M3", pos, 0)
    fp.SetReference(ref_name)
    ref = fp.Reference()
    ref.SetVisible(True)
    ref.SetTextSize(pcbnew.VECTOR2I(MM(1.0), MM(1.0)))
    ref.SetTextThickness(MM(0.15))

# ---- Bus routing: inner layers only. J2 escapes UPWARD into the lanes (as before);
# J1 (now near the top of its zone) escapes DOWNWARD into the same lane band. ----
LANE_Y0 = 26.5
LANE_STEP = 0.93
STUB_LAYER = pcbnew.In1_Cu
BUS_LAYER = pcbnew.In2_Cu
SIG_W = MM(0.25)
PWR_W = MM(0.25)
VIA_DIA = MM(0.6)
VIA_DRILL = MM(0.3)
FAR_NUDGE = MM(1.27)

def make_track(start, end, layer, width, net):
    t = pcbnew.PCB_TRACK(board)
    t.SetStart(start)
    t.SetEnd(end)
    t.SetLayer(layer)
    t.SetWidth(width)
    t.SetNet(net)
    board.Add(t)

def make_via(pos, net):
    v = pcbnew.PCB_VIA(board)
    v.SetPosition(pos)
    v.SetWidth(VIA_DIA)
    v.SetDrill(VIA_DRILL)
    v.SetNet(net)
    board.Add(v)

# far_parity: which pin parity (of THIS connector) is the one whose row is farther from
# the lane band and needs the sideways jog to clear its row-mate's pad.
#   J2 (unflipped, escapes up): even row (18.74) is below odd (21.28) -> even is farther. (unchanged)
#   J1 (flipped, escapes down): even row (70.26) is farther below odd (67.72) -> even is
#       farther from the lanes (which are below both rows).
FAR_PARITY = {"J1": 0, "J2": 0}

j1_bends = {}
j2_bends = {}

for pin in range(1, 41):
    netname = PINMAP[pin]
    net = nets[netname]
    w = PWR_W if netname in POWER_NETS else SIG_W
    lane_y = MM(LANE_Y0 + (pin - 1) * LANE_STEP)

    for fp, bends, ref in ((j1, j1_bends, "J1"), (j2, j2_bends, "J2")):
        pad_pos = fp.FindPadByNumber(str(pin)).GetPosition()
        is_far = (pin % 2) == FAR_PARITY[ref]
        if is_far:
            jog = pcbnew.VECTOR2I(pad_pos.x + FAR_NUDGE, pad_pos.y)
            bend = pcbnew.VECTOR2I(pad_pos.x + FAR_NUDGE, lane_y)
            make_track(pad_pos, jog, STUB_LAYER, w, net)
            make_track(jog, bend, STUB_LAYER, w, net)
        else:
            bend = pcbnew.VECTOR2I(pad_pos.x, lane_y)
            make_track(pad_pos, bend, STUB_LAYER, w, net)
        make_via(bend, net)
        bends[pin] = bend

    make_track(j2_bends[pin], j1_bends[pin], BUS_LAYER, w, net)

# ---- Board outline ----
outline = pcbnew.PCB_SHAPE(board)
outline.SetShape(pcbnew.SHAPE_T_RECT)
outline.SetStart(pcbnew.VECTOR2I(MM(bx0), MM(by0)))
outline.SetEnd(pcbnew.VECTOR2I(MM(bx1), MM(by1)))
outline.SetLayer(pcbnew.Edge_Cuts)
outline.SetWidth(MM(0.1))
board.Add(outline)

def add_text(text, pos_mm, layer=pcbnew.F_SilkS, size_mm=1.4, rot_deg=0):
    t = pcbnew.PCB_TEXT(board)
    t.SetText(text)
    t.SetPosition(pcbnew.VECTOR2I(MM(pos_mm[0]), MM(pos_mm[1])))
    t.SetLayer(layer)
    t.SetTextSize(pcbnew.VECTOR2I(MM(size_mm), MM(size_mm)))
    t.SetTextThickness(MM(size_mm * 0.15))
    if rot_deg:
        t.SetTextAngleDegrees(rot_deg)
    board.Add(t)

# Minimal labelling only, per feedback: just which side is which, and male/female.
# Sit in the clear strip between the row-1 holes and the routing lanes.
add_text("EXPANSION SIDE (male)", (HAT_H1[0] + 6, HAT_H1[1] + 4.6), size_mm=0.9)
add_text("PI SIDE (female)", (PI_H1[0] + 6, PI_H1[1] + 4.6), size_mm=0.9)

# Nudge panel-hole reference text off their own hole's solder mask, and clear of the
# EXPANSION SIDE label above.
for ref_name, pos in panel_holes.items():
    for fp in board.GetFootprints():
        if fp.GetReference() == ref_name:
            fp.Reference().SetPosition(pcbnew.VECTOR2I(MM(pos[0]), MM(pos[1] + 3.5)))

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "openmanet_gpio_adapter.kicad_pcb")
pcbnew.SaveBoard(OUT, board)
print("Saved:", OUT)
print("Board size:", bx1 - bx0, "x", by1 - by0, "mm")
print("J1 anchor (flipped Pi4, odd-row pin1):", J1_ANCHOR_X, J1_ANCHOR_Y)
print("J1 pin2 (even, should be 5.08mm below pin1):", pcbnew.ToMM(j1.FindPadByNumber("2").GetPosition().x), pcbnew.ToMM(j1.FindPadByNumber("2").GetPosition().y))
print("J1 pin1 net:", j1.FindPadByNumber("1").GetNetname(), " J1 pin2 net:", j1.FindPadByNumber("2").GetNetname())
print("J2 pin1 net:", j2.FindPadByNumber("1").GetNetname(), " J2 pin2 net:", j2.FindPadByNumber("2").GetNetname())
